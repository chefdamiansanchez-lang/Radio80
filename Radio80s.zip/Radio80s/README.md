# Radio 80s 📻

App Android para buscar y escuchar en vivo estaciones de radio del mundo que pasan música de los 80, con reproducción en segundo plano.

## Funciones
- Buscador por nombre de estación
- Filtro por país
- Reproducción en streaming en segundo plano (notificación con controles)
- Favoritos guardados en el dispositivo
- Diseño colorido estilo dial vintage

## Cómo subir esto a GitHub y descargar la app instalable

1. Creá un repositorio nuevo en GitHub (puede ser privado).
2. Subí **todo el contenido de este zip** (descomprimido) a la raíz del repositorio. Se puede hacer directo desde el navegador del celular: en GitHub, "Add file" → "Upload files", y arrastrás todos los archivos y carpetas (respetando la estructura de carpetas, incluyendo `.github/workflows/build.yml`).
3. Andá a la pestaña **Actions** del repositorio. Se va a disparar automáticamente el workflow "Build APK" (tarda unos 3-5 minutos).
4. Cuando termine (tilde verde ✅), entrá a esa ejecución y bajá hasta "Artifacts". Ahí vas a encontrar **Radio80s-debug-apk** para descargar.
5. Descomprimí ese zip en tu celular, vas a encontrar `app-debug.apk`.
6. Tocá el APK para instalarlo (puede pedirte habilitar "instalar apps de orígenes desconocidos" la primera vez).

Listo, la app queda instalada con su ícono en el dispositivo.

## Notas técnicas
- Usa la API pública y gratuita de Radio Browser (radio-browser.info), sin necesidad de API key.
- Reproducción con Media3/ExoPlayer.
