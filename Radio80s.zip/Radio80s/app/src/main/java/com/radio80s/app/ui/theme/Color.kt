package com.radio80s.app.ui.theme

import androidx.compose.ui.graphics.Color

val VintagePurple = Color(0xFF2D1B4E)
val VintagePurpleLight = Color(0xFF4A2E7A)
val VintageOrange = Color(0xFFFF6B35)
val VintageYellow = Color(0xFFFFD23F)
val VintageTeal = Color(0xFF4ECDC4)
val VintagePink = Color(0xFFEE4266)
val CreamWhite = Color(0xFFFFF5E6)
