package com.radio80s.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Guarda las estaciones favoritas localmente en SharedPreferences (sin servidor).
 */
class FavoritesStore(context: Context) {
    private val prefs = context.getSharedPreferences("radio80s_favorites", Context.MODE_PRIVATE)

    fun getFavorites(): List<RadioStation> {
        val json = prefs.getString("list", "[]") ?: "[]"
        val arr = JSONArray(json)
        val result = mutableListOf<RadioStation>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            result.add(
                RadioStation(
                    stationUuid = o.optString("stationUuid"),
                    name = o.optString("name"),
                    url = o.optString("url"),
                    country = o.optString("country"),
                    tags = o.optString("tags"),
                    favicon = o.optString("favicon"),
                    bitrate = o.optInt("bitrate", 0)
                )
            )
        }
        return result
    }

    fun isFavorite(uuid: String): Boolean = getFavorites().any { it.stationUuid == uuid }

    fun toggleFavorite(station: RadioStation) {
        val current = getFavorites().toMutableList()
        val idx = current.indexOfFirst { it.stationUuid == station.stationUuid }
        if (idx >= 0) current.removeAt(idx) else current.add(station)
        val arr = JSONArray()
        current.forEach { s ->
            val o = JSONObject()
            o.put("stationUuid", s.stationUuid)
            o.put("name", s.name)
            o.put("url", s.url)
            o.put("country", s.country)
            o.put("tags", s.tags)
            o.put("favicon", s.favicon)
            o.put("bitrate", s.bitrate)
            arr.put(o)
        }
        prefs.edit().putString("list", arr.toString()).apply()
    }
}
