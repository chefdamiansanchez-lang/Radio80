package com.radio80s.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class RadioUiState(
    val query: String = "",
    val countryCode: String? = null,
    val stations: List<RadioStation> = emptyList(),
    val favorites: List<RadioStation> = emptyList(),
    val showFavoritesOnly: Boolean = false,
    val isLoading: Boolean = false,
    val currentStation: RadioStation? = null,
    val isPlaying: Boolean = false,
    val error: String? = null
)

class RadioViewModel(application: Application) : AndroidViewModel(application) {

    private val api = RadioApiClient()
    private val favoritesStore = FavoritesStore(application)

    private val _uiState = MutableStateFlow(RadioUiState())
    val uiState: StateFlow<RadioUiState> = _uiState.asStateFlow()

    init {
        refreshFavorites()
        search()
    }

    fun onQueryChange(newQuery: String) {
        _uiState.value = _uiState.value.copy(query = newQuery)
    }

    fun onCountryChange(code: String?) {
        _uiState.value = _uiState.value.copy(countryCode = code)
        search()
    }

    fun toggleShowFavorites() {
        _uiState.value = _uiState.value.copy(showFavoritesOnly = !_uiState.value.showFavoritesOnly)
    }

    fun search() {
        val state = _uiState.value
        _uiState.value = state.copy(isLoading = true, error = null)
        viewModelScope.launch {
            try {
                val results = withContext(Dispatchers.IO) {
                    api.search(state.query, state.countryCode)
                }
                _uiState.value = _uiState.value.copy(stations = results, isLoading = false)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = "No se pudo conectar. Revisá tu conexión a internet."
                )
            }
        }
    }

    fun toggleFavorite(station: RadioStation) {
        favoritesStore.toggleFavorite(station)
        refreshFavorites()
    }

    fun isFavorite(uuid: String): Boolean = favoritesStore.isFavorite(uuid)

    private fun refreshFavorites() {
        _uiState.value = _uiState.value.copy(favorites = favoritesStore.getFavorites())
    }

    fun setPlaying(station: RadioStation?, playing: Boolean) {
        _uiState.value = _uiState.value.copy(currentStation = station, isPlaying = playing)
    }
}
