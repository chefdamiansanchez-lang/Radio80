package com.radio80s.app

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Cliente para la API pública y gratuita de Radio Browser (radio-browser.info).
 * No requiere API key. Se filtra por tag "80s" para cumplir el criterio de búsqueda del usuario.
 */
class RadioApiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    // Servidor base de la API (round-robin público)
    private val baseUrl = "https://de1.api.radio-browser.info/json/stations/search"

    fun search(nameQuery: String, countryCode: String?): List<RadioStation> {
        val urlBuilder = StringBuilder(baseUrl)
        urlBuilder.append("?tagList=").append(URLEncoder.encode("80s", "UTF-8"))
        urlBuilder.append("&order=votes&reverse=true&limit=60&hidebroken=true")

        if (nameQuery.isNotBlank()) {
            urlBuilder.append("&name=").append(URLEncoder.encode(nameQuery, "UTF-8"))
        }
        if (!countryCode.isNullOrBlank()) {
            urlBuilder.append("&countrycode=").append(countryCode)
        }

        val request = Request.Builder()
            .url(urlBuilder.toString())
            .header("User-Agent", "Radio80sApp/1.0")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return emptyList()
            val body = response.body?.string() ?: return emptyList()
            return parseStations(body)
        }
    }

    private fun parseStations(json: String): List<RadioStation> {
        val result = mutableListOf<RadioStation>()
        val arr = JSONArray(json)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val streamUrl = obj.optString("url_resolved").ifBlank { obj.optString("url") }
            if (streamUrl.isBlank()) continue
            result.add(
                RadioStation(
                    stationUuid = obj.optString("stationuuid"),
                    name = obj.optString("name").ifBlank { "Sin nombre" },
                    url = streamUrl,
                    country = obj.optString("country"),
                    tags = obj.optString("tags"),
                    favicon = obj.optString("favicon"),
                    bitrate = obj.optInt("bitrate", 0)
                )
            )
        }
        return result
    }
}
