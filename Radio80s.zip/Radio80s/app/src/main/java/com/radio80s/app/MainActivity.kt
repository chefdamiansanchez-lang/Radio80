package com.radio80s.app

import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.radio80s.app.ui.theme.Radio80sTheme
import com.radio80s.app.ui.theme.VintageOrange
import com.radio80s.app.ui.theme.VintagePurpleLight
import com.radio80s.app.ui.theme.VintageTeal
import com.radio80s.app.ui.theme.VintageYellow

private val countries = listOf(
    "Todos" to null,
    "Argentina" to "AR",
    "España" to "ES",
    "México" to "MX",
    "Estados Unidos" to "US",
    "Reino Unido" to "GB",
    "Alemania" to "DE",
    "Brasil" to "BR"
)

@UnstableApi
class MainActivity : ComponentActivity() {

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null

    private val viewModel: RadioViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sessionToken = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, sessionToken).buildAsync()
        controllerFuture?.addListener({
            mediaController = controllerFuture?.get()
        }, MoreExecutors.directExecutor())

        setContent {
            Radio80sTheme {
                RadioApp(
                    viewModel = viewModel,
                    onPlay = { station -> playStation(station) },
                    onPause = { pausePlayback() }
                )
            }
        }
    }

    private fun playStation(station: RadioStation) {
        val controller = mediaController ?: return
        controller.setMediaItem(MediaItem.fromUri(station.url))
        controller.prepare()
        controller.play()
        viewModel.setPlaying(station, true)
    }

    private fun pausePlayback() {
        mediaController?.pause()
        val current = viewModel.uiState.value.currentStation
        viewModel.setPlaying(current, false)
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RadioApp(
    viewModel: RadioViewModel,
    onPlay: (RadioStation) -> Unit,
    onPause: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "📻 Radio 80s",
                        fontWeight = FontWeight.ExtraBold
                    )
                },
                actions = {
                    IconButton(onClick = { viewModel.toggleShowFavorites() }) {
                        Icon(
                            if (state.showFavoritesOnly) Icons.Filled.Star else Icons.Filled.StarBorder,
                            contentDescription = "Favoritos",
                            tint = VintageYellow
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = VintagePurpleLight
                )
            )
        },
        bottomBar = {
            if (state.currentStation != null) {
                MiniPlayer(
                    station = state.currentStation!!,
                    isPlaying = state.isPlaying,
                    onPlayPause = {
                        if (state.isPlaying) onPause() else onPlay(state.currentStation!!)
                    }
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = state.query,
                onValueChange = { viewModel.onQueryChange(it) },
                label = { Text("Buscar estación de radio") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                    onSearch = { viewModel.search() }
                )
            )

            Spacer(Modifier.height(4.dp))
            Text(
                "🎵 Filtrando por música de los 80",
                style = MaterialTheme.typography.labelSmall,
                color = VintageTeal
            )

            Spacer(Modifier.height(12.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(countries) { (label, code) ->
                    FilterChip(
                        selected = state.countryCode == code,
                        onClick = { viewModel.onCountryChange(code) },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = VintageOrange
                        )
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { viewModel.search() },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = VintageOrange)
            ) {
                Icon(Icons.Filled.Search, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Buscar")
            }

            Spacer(Modifier.height(12.dp))

            val listToShow = if (state.showFavoritesOnly) state.favorites else state.stations

            when {
                state.isLoading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = VintageOrange)
                    }
                }
                state.error != null -> {
                    Text(state.error!!, color = MaterialTheme.colorScheme.error)
                }
                listToShow.isEmpty() -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            if (state.showFavoritesOnly) "Todavía no tenés favoritos"
                            else "No se encontraron estaciones",
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
                else -> {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(listToShow, key = { it.stationUuid }) { station ->
                            StationCard(
                                station = station,
                                isPlaying = state.currentStation?.stationUuid == station.stationUuid && state.isPlaying,
                                isFavorite = viewModel.isFavorite(station.stationUuid),
                                onPlay = { onPlay(station) },
                                onPause = { onPause() },
                                onToggleFavorite = { viewModel.toggleFavorite(station) }
                            )
                        }
                        item { Spacer(Modifier.height(80.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
fun StationCard(
    station: RadioStation,
    isPlaying: Boolean,
    isFavorite: Boolean,
    onPlay: () -> Unit,
    onPause: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = VintagePurpleLight),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(VintageOrange),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Radio, contentDescription = null, tint = VintagePurpleLight)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    station.name,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    station.country.ifBlank { "País desconocido" },
                    style = MaterialTheme.typography.labelSmall
                )
            }
            IconButton(onClick = onToggleFavorite) {
                Icon(
                    if (isFavorite) Icons.Filled.Star else Icons.Filled.StarBorder,
                    contentDescription = "Favorito",
                    tint = VintageYellow
                )
            }
            IconButton(onClick = { if (isPlaying) onPause() else onPlay() }) {
                Icon(
                    if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = "Reproducir",
                    tint = VintageTeal
                )
            }
        }
    }
}

@Composable
fun MiniPlayer(station: RadioStation, isPlaying: Boolean, onPlayPause: () -> Unit) {
    Surface(color = VintageOrange, shadowElevation = 8.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Radio, contentDescription = null)
            Spacer(Modifier.width(10.dp))
            Text(
                station.name,
                modifier = Modifier.weight(1f),
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            IconButton(onClick = onPlayPause) {
                Icon(
                    if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = null
                )
            }
        }
    }
}
