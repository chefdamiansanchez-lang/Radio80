package com.radio80s.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val VintageColorScheme = darkColorScheme(
    primary = VintageOrange,
    onPrimary = VintagePurple,
    secondary = VintageTeal,
    onSecondary = VintagePurple,
    tertiary = VintageYellow,
    background = VintagePurple,
    onBackground = CreamWhite,
    surface = VintagePurpleLight,
    onSurface = CreamWhite,
    error = VintagePink
)

@Composable
fun Radio80sTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = VintageColorScheme,
        typography = Typography,
        content = content
    )
}
