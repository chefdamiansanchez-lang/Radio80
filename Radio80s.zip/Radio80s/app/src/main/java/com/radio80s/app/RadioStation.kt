package com.radio80s.app

data class RadioStation(
    val stationUuid: String,
    val name: String,
    val url: String,
    val country: String,
    val tags: String,
    val favicon: String,
    val bitrate: Int
)
